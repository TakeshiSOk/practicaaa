<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArmyCorps extends Model
{
    public function soldiers()
    {
        return $this->hasMany(Soldier::class, 'army_corp_id');
    }

    // Buscar por denominación
public function scopeByDenominacion($query, $denominacion)
{
    return $query->where('denominacion', $denominacion);
}
}

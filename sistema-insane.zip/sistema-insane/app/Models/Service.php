<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    public function soldiers()
    {
        return $this->belongsToMany(Soldier::class, 'soldier_service');
    }

    // Filtrar por tipo de actividad
public function scopeByActividad($query, $actividad)
{
    return $query->where('actividad_servicio', $actividad);
}
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    public function soldiers()
    {
        return $this->hasMany(Soldier::class, 'company_id');
    }
}

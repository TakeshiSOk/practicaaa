<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Soldier extends Model
{
    public function armyCorps()
{
    return $this->belongsTo(ArmyCorps::class, 'army_corp_id');
}

public function quarter()
{
    return $this->belongsTo(Quarter::class, 'quarter_id');
}

public function company()
{
    return $this->belongsTo(Company::class, 'company_id');
}

public function services()
{
    return $this->belongsToMany(Service::class, 'soldier_service');
}

//scopes 

// Filtrar por grado
public function scopeByGrado($query, $grado)
{
    return $query->where('grado', $grado);
}

// Filtrar por cuerpo del ejército
public function scopeByArmyCorps($query, $armyCorpId)
{
    return $query->where('army_corps_id', $armyCorpId);
}

// Filtrar por cuartel
public function scopeByQuarter($query, $quarterId)
{
    return $query->where('quarter_id', $quarterId);
}

// Filtrar por compañía
public function scopeByCompany($query, $companyId)
{
    return $query->where('company_id', $companyId);
}
}

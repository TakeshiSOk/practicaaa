<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SoldierService extends Model
{
    protected $table = 'soldier_service';
}

//la pivote se protege con $table, no se le asigna nada mas porque es una tabla pivote, no tiene relaciones propias, solo las de belongsToMany en los modelos relacionados.
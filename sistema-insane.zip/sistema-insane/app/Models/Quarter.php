<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Quarter extends Model
{
    public function soldiers()
    {
        return $this->hasMany(Soldier::class, 'quarter_id');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Soldier;
use Illuminate\Http\Request;

class SoldierController extends Controller
{
    // Trae todos los soldados
    public function index()
    {
        $soldiers = Soldier::all();
        return response()->json($soldiers);
    }

    // Trae soldados por grado
    public function byGrado($grado)
    {
        $soldiers = Soldier::byGrado($grado)->get();
        return response()->json($soldiers);
    }

    // Trae soldados por cuartel
    public function byQuarter($quarterId)
    {
        $soldiers = Soldier::byQuarter($quarterId)->get();
        return response()->json($soldiers);
    }

    // Trae soldados por compañia
    public function byCompany($companyId)
    {
        $soldiers = Soldier::byCompany($companyId)->get();
        return response()->json($soldiers);
    }

    // Trae soldados por cuerpo del ejercito
    public function byArmyCorps($armyCorpId)
    {
        $soldiers = Soldier::byArmyCorps($armyCorpId)->get();
        return response()->json($soldiers);
    }
}
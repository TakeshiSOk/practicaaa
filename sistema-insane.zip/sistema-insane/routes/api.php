<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SoldierController;

Route::get('/soldiers', [SoldierController::class, 'index']);
Route::get('/soldiers/grado/{grado}', [SoldierController::class, 'byGrado']);
Route::get('/soldiers/quarter/{quarterId}', [SoldierController::class, 'byQuarter']);
Route::get('/soldiers/company/{companyId}', [SoldierController::class, 'byCompany']);
Route::get('/soldiers/army-corps/{armyCorpId}', [SoldierController::class, 'byArmyCorps']);


Route::get('/user', function (Request $request) {
    
    return $request->user();
})->middleware('auth:sanctum');

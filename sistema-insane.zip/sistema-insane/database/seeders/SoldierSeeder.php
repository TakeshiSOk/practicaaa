<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Soldier;
use App\Models\ArmyCorps;
use App\Models\Quarter;
use App\Models\Company;

class SoldierSeeder extends Seeder
{
    public function run(): void
    {
        // Primero creamos los datos de las tablas padre
        $armyCorps = ArmyCorps::create(['denominacion' => 'Infantería']);
        $quarter = Quarter::create(['nombre' => 'Cuartel Norte', 'ubicacion' => 'Bogotá']);
        $company = Company::create(['Actividad' => 'Patrullaje']);

        // Luego creamos soldados
        Soldier::create([
            'nombre' => 'Juan',
            'apellido' => 'García',
            'grado' => 'Cabo',
            'army_corp_id' => $armyCorps->id,
            'quarter_id' => $quarter->id,
            'company_id' => $company->id,
        ]);

        Soldier::create([
            'nombre' => 'Pedro',
            'apellido' => 'López',
            'grado' => 'Sargento',
            'army_corp_id' => $armyCorps->id,
            'quarter_id' => $quarter->id,
            'company_id' => $company->id,
        ]);
    }
}
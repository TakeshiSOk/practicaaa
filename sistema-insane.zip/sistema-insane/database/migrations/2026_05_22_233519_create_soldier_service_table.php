<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('soldier_service', function (Blueprint $table) {
            $table->id();
            $table->foreignId('soldier_id')->constrained('soldiers');
            $table->foreignId('service_id')->constrained('services');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('soldier_service');
    }
};
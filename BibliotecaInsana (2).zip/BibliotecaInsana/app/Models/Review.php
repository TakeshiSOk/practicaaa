<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

        // Filtrar por calificación
    public function scopeByCalificacion($query, $calificacion)
    {
        return $query->where('calificacion', '>=', $calificacion);
    }

        // Filtrar por producto
    public function scopeByProducto($query, $productId)
    {
        return $query->where('product_id', $productId);
    }

}

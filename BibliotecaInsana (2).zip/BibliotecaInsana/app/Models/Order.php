<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function products()
    {
        return $this->belongsToMany(Product::class, 'order_products');
    }

    // Filtrar por precio
    public function scopeByClient($query, $clientId)
    {
        return $query->where('customer_id', $clientId);
    }

        // Filtrar por fecha
    public function scopeByFecha($query, $fecha)
    {
        return $query->where('fecha', '>=', $fecha);
    }
}

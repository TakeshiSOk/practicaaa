<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function orders()
{
    return $this->belongsToMany(Order::class, 'order_products');
}

public function reviews()
{
    return $this->hasMany(Review::class);
}

// Filtrar por categoría
public function scopeByCategory($query, $categoryId)
{
    return $query->where('category_id', $categoryId);
}

    // Filtrar por precio
    public function scopeByPrice($query, $price)
    {
        return $query->where('precio', '>=', $price);
    }

        // Filtrar por stock
    public function scopeByStock($query, $stock)
    {
        return $query->where('stock', '>=', $stock);
    }
}

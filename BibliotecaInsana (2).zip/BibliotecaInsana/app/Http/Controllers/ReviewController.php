<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Review;

class ReviewController extends Controller
{
        public function byCalificacion($calificacion)
    {
        $reviews = Review::byCalificacion($calificacion)->get();
        return response()->json($reviews);
    }

    public function byProducto($product)
    {
        $reviews = Review::byProducto($product)->get();
        return response()->json($reviews);
    }
}

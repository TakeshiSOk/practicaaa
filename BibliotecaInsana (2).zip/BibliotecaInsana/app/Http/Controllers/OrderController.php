<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    // Trae productos por cliente
    public function byClient($clientId)
    {
        $orders = Order::byClient($clientId)->get();
        return response()->json($orders);
    }

    // Trae productos por fecha de creación
    public function byFecha($fecha)
    {
        $orders = Order::byFecha($fecha)->get();
        return response()->json($orders);
    }
}

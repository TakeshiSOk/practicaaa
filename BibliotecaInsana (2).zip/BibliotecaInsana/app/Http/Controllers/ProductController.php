<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
        // Trae todos los productos
    public function index()
    {
        $products = Product::all();
        return response()->json($products);
    }

    // Trae productos por categoría
    public function byCategory($categoryId)
    {
        $products = Product::byCategory($categoryId)->get();
        return response()->json($products);
    }

    // Trae productos por precio
    public function byPrice($price)
    {
        $products = Product::byPrice($price)->get();
        return response()->json($products);
    }

    // Trae productos por stock
    public function byStock($stock)
    {
        $products = Product::byStock($stock)->get();
        return response()->json($products);
    }

    
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Order;
use App\Models\Review;
use App\Models\OrderProduct;

class EcommerceSeeder extends Seeder
{
    public function run(): void
    {
        // Primero creamos los datos de las tablas padre
        $categories = Category::create(['nombre' => 'Sok', 'descripcion' => 'Un tipo exesivamente insano de sok']);
        $customers = Customer::create(['nombre' => 'Juan', 'email' => 'juan@example.com', 'telefono' => '3207705450' ]);
    

        // Luego creamos productos
        $product = Product::create([
            'nombre' => 'Juan',
            'precio' => 1000,
            'stock' => 10,
            'category_id' => $categories->id,
        ]);
                // Luego creamos órdenes
        $order = Order::create([
            'customer_id' => $customers->id,
            'fecha' => '2023-01-01',
            'total' => 2000,
        ]);

        //luego creamos reviews
        $review = Review::create([
            'product_id' => $product->id,
            'customer_id' => $customers->id,
            'calificacion' => 5,
            'comentario' => 'Excelente producto',
        ]);

        // Luego creamos order_products
        $orderProduct = OrderProduct::create([
            'order_id' => $order->id,
            'product_id' => $product->id,


        ]);
    }
}


    


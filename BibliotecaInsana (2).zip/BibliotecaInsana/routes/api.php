<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ReviewController;

//rutas de productos
Route::get('/products', [ProductController::class, 'index']);
Route::get('/products/categories/{categoryId}', [ProductController::class, 'byCategory']);
Route::get('/products/precio/{precio}', [ProductController::class, 'byPrice']);
Route::get('/products/stock/{stock}', [ProductController::class, 'byStock']);


//rutas de órdenes
Route::get('/orders', [OrderController::class, 'index']);
Route::get('/orders/client/{clientId}', [OrderController::class, 'byClient']);
Route::get('/orders/fecha/{fechaId}', [OrderController::class, 'byFecha']);

//rutas de reseñas
Route::get('/reviews', [ReviewController::class, 'index']);
Route::get('/reviews/calificacion/{calificacion}', [ReviewController::class, 'byCalificacion']);
Route::get('/reviews/product/{product}', [ReviewController::class, 'byProductId']);



Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
